---
name: mod-recommendation
description: Recommend 3 to 5 GTA V Legacy Story Mode mod ideas based on a requested style such as Funny, Gang, Police, Racing, Survival, Delivery, Horror, or a mixed surprise set. Use when the user asks what mod they should make, wants new ideas, wants recommendations, or does not know what to build next.
---

# Mod Recommendation

Recommend mod ideas that are fun, buildable, and suitable for GTA V Legacy Story Mode.

## Recommendation behavior

When the user asks "What mod should I make?" or similar:

- Give 3 to 5 distinct ideas.
- If the user named a category, stay mostly within it.
- If no category is given, provide a varied mix instead of blocking on a question.
- Keep ideas meaningfully different from one another.
- Avoid cheat-oriented concepts and redirect any cheat-like idea into a fair gameplay mechanic.

## For each recommendation include

- **Mod Name**
- **Category**: Funny, Gang, Police, Racing, Survival, Delivery, Horror, World Event, etc.
- **Core Loop**: what the player repeatedly does
- **Hook**: the funny, dramatic, or unusual part that makes it memorable
- **Difficulty to Build**: Easy / Medium / Hard
- **Likely Dependencies**: only what is actually likely to be needed
- **Best First Version**: the smallest playable v1 scope

## Extra recommendation functions

### Quick Pick

If the user wants something fast, choose one idea and explain why it is the best starter project.

### Remix

If the user likes an idea but wants it stranger, remix it by combining two compatible categories, for example:

- Police + Survival
- Delivery + Gang
- Racing + World Event
- Funny + Horror

### Upgrade Existing Idea

If the user already has a mod concept, suggest 3 useful additions ordered by impact and implementation difficulty.

### Avoid repetition

Within the current conversation, do not keep recommending the same concept with only renamed NPCs or locations. Change the gameplay loop, objective structure, or player role.

## Handoff

When the user picks an idea, summarize the chosen design in a compact build brief and hand it off to the main GTA V Legacy Mod Creator workflow for real implementation, files, installation instructions, and packaging.
