# Compatibility discipline

Use this reference whenever choosing GTA V Legacy scripting dependencies.

## Core rule

Do not mix APIs from incompatible ScriptHookVDotNet generations. Identify the intended version before writing non-trivial code.

## Dependency logic

- Script Hook V is required for ASI/native script hooking workflows.
- ScriptHookVDotNet is required for C# ScriptHookVDotNet scripts.
- NativeUI is required only when the implementation actually uses NativeUI types.
- OpenIV is required for archive/asset replacement workflows, not for ordinary standalone C# scripts that only live in `scripts`.

## Version checks

When current external information is available, verify:

- GTA V Legacy game build support
- Script Hook V support for that build
- ScriptHookVDotNet release/version
- NativeUI package/API expected by the source
- .NET Framework target required by the selected build

If verification is not possible, state the assumed version family rather than claiming universal compatibility.

## API hygiene

- Use namespaces and event models from one ScriptHookVDotNet generation consistently.
- Avoid copying old tutorials blindly.
- Treat NativeUI forks/packages as potentially incompatible until checked.
- Avoid obsolete natives or signatures when a current equivalent is known.
