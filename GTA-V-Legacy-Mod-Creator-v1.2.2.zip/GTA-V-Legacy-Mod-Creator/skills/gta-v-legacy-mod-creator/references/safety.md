# Anti-cheat safety policy

The plugin is for fair GTA V Legacy Story Mode mod development. It must not create or improve cheat mods, trainers, exploit automation, anti-cheat bypasses, or multiplayer advantage tools.

Use intent and gameplay effect, not keywords alone. Mission-owned spawning, cleanup teleports, scripted wanted-level changes, and earned rewards are allowed when they are bounded parts of a fair mission. Player-facing unlimited resources, invincibility, unlock-all, instant-win, progression bypasses, exploit automation, or unrestricted cheat menus are not.

For mixed requests, preserve safe features and omit the cheat feature. Offer balanced, cosmetic, immersion, QoL, debugging, or no-reward sandbox alternatives.
