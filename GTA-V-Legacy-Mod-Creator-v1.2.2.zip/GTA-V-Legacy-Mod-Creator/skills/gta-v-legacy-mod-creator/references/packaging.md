# Release packaging checklist

Use this before creating a ZIP or release bundle.

## Package contents

Include only files that the user needs:

- source or compiled DLL
- INI/XML config
- README
- INSTALL
- CHANGELOG when relevant

Do not include fake DLLs, temporary build folders, IDE caches, or unrelated assets.

## INSTALL.txt minimum

State:

- target game: GTA V Legacy
- Story Mode only
- tested/assumed launcher target
- dependencies and why they are needed
- exact root-folder files
- exact `scripts`-folder files
- hotkeys
- first launch steps
- uninstall steps
- warning not to use in GTA Online

## Release status language

Use one of these accurately:

- Source generated, not compiled
- Source generated and statically reviewed
- Compilation successful
- Runtime tested in GTA V Legacy

Never escalate the status beyond available evidence.

## Variant packaging

For reward/no-reward source variants, make filenames unmistakable and say to install one only.
