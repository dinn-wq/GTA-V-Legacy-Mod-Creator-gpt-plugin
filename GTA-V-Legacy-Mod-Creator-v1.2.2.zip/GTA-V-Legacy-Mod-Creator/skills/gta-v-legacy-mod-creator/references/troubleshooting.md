# Troubleshooting checklist

## Script does not load

Check:

- correct GTA V Legacy install
- Script Hook V files in root
- ScriptHookVDotNet files in root
- `scripts` folder exists
- script/DLL is in correct folder
- required runtime/framework is installed
- ScriptHookVDotNet logs for load exceptions

## Menu does not appear

Check:

- open-menu key conflicts
- script `Tick` or menu-pool processing runs
- NativeUI assembly is present if required
- menu is initialized once
- input events are registered
- no exception occurred before menu creation

## Enter does not select

Check:

- menu pool/process call occurs every tick
- menu is visible and focused
- item activation/select event is registered
- selected item is not disabled
- NativeUI API matches the referenced version

## NPC/vehicle does not spawn

Check:

- model hash/name is valid
- model is requested and loaded before creation
- spawn coordinate is valid
- entity handle exists after creation
- cleanup code is not immediately deleting it

## Marker/blip missing

Check:

- blip is created after the target entity/location exists
- blip reference is retained
- cleanup/state code is not removing it early
- sprite/color/visibility values are valid

## Crash or exception

Request exact exception text and logs. Identify the line/file first. Distinguish:

- dependency load failure
- API mismatch
- null/deleted entity
- invalid native parameters
- runaway spawn loop
- repeated event registration
- stale handle after cleanup

Provide the smallest safe patch and identify the exact replacement file.
