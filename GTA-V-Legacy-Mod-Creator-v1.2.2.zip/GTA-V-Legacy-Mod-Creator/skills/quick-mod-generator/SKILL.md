---
name: quick-mod-generator
description: Instantly create a GTA V Legacy Story Mode mod from one simple category choice such as Gang, Police, Funny, Racing, Survival, Delivery, Horror, or World Event. Use when the user wants a fast mod generator, says they want to choose one category and have the rest created automatically, or asks for a mod without wanting a long design interview.
---

# Quick Mod Generator

Create a build-ready GTA V Legacy Story Mode mod from the smallest possible amount of user input.

## Main behavior

The ideal flow is:

**Choose one category -> Generate the complete mod concept -> Build it.**

Do not turn this workflow into a long questionnaire.

If the user provides only a category, infer the rest and continue immediately.

Supported quick categories include:

- Gang
- Police
- Funny
- Racing
- Survival
- Delivery
- Horror
- World Event
- Random / Surprise Me

If the user names another safe Story Mode category, accept it.

## Automatic decisions

After the user chooses a category, automatically decide sensible values for:

- Mod name
- Main gameplay loop
- Start location
- Mission objectives
- NPC roles and bounded NPC counts
- Vehicles when relevant
- Difficulty
- Balanced rewards or no-reward mode
- Map markers
- GTA-style notifications
- Controls / hotkey
- Required dependencies
- Replay and cleanup behavior
- Smallest useful v1 scope

Prefer simple, reliable implementations over feature bloat.

## Category examples

### Gang
Create a compact gang job such as defending territory, ambushing a rival crew, stealing a mission vehicle, or rescuing an ally.

### Police
Create a fair Story Mode police-assistance job such as responding to a robbery, chasing a suspect, protecting an officer, or securing a crime scene.

### Funny
Create a ridiculous but playable job such as chaotic pizza delivery, runaway NPC chase, broken taxi job, wrong-car pickup, or a strange random event.

### Racing
Create a checkpoint race, escape race, timed street run, or rival-driver challenge with bounded traffic/NPC logic.

### Survival
Create a wave or holdout mission with finite enemy counts, clear completion conditions, and reliable cleanup.

### Delivery
Create a delivery route with one or more complications such as a chase, damaged cargo, time pressure, or hostile NPCs.

### Horror
Create a tense Story Mode event using lighting, location, NPC behavior, limited encounters, and objectives rather than unfair player debuffs.

### World Event
Create a repeatable event that can appear at a defined location or trigger, such as a roadside fight, robbery, stranded driver, or gang shootout.

## Fast output format

Before implementation, provide a compact build brief:

- **Mod:** name
- **Category:** selected category
- **Gameplay:** one or two sentences
- **Location:** chosen area
- **Difficulty:** Easy / Normal / Hard
- **Reward:** balanced reward or none
- **Controls:** chosen key / interaction
- **Dependencies:** only what is actually required

Then move directly into real implementation using the main GTA V Legacy Mod Creator standards.

## Surprise Me mode

If the user says `Surprise Me`, `Random`, or equivalent:

1. Choose a safe category.
2. Generate the complete design automatically.
3. Avoid repeating the same concept already suggested in the current conversation.
4. Build without asking extra design questions unless a technical blocker genuinely prevents implementation.

## Dependency discipline

Do not add NativeUI merely because a menu looks nice. Use it only when the generated mod actually benefits from a menu.

Do not add OpenIV for ordinary script mods.

Select a compatible ScriptHookVDotNet target before generating C# code.

## Safety

Apply the plugin anti-cheat policy. Never turn Quick Mod Generator into a trainer, unlimited-resource menu, progression bypass, exploit, anti-cheat bypass, or multiplayer advantage tool.

If a generated idea accidentally approaches cheat behavior, automatically replace that mechanic with a fair mission-scoped alternative.

## Completion

When the category is known, do not keep asking what the user wants next. Generate the mod brief and proceed to code/files, installation instructions, and packaging when tools allow.
