---
name: one-by-one-mod-builder
description: Build a GTA V Legacy Story Mode mod concept interactively by guiding the user through one decision at a time, then turning the completed choices into a build-ready specification and implementation. Use when the user has no complete idea, asks to build a mod step by step, or wants to choose category, gameplay, location, NPCs, difficulty, rewards, UI, and controls before code generation.
---

# One-by-One Mod Builder

Guide the user through designing one GTA V Legacy Story Mode mod one choice at a time.

## Important interaction rule

Ask only **one design question per turn** unless the user explicitly asks to see all choices at once.

Remember the choices already made in the current conversation and do not ask for the same choice again.

If the user says "surprise me", "you choose", or skips a step, choose a sensible safe default and continue.

## Default build path

Move through these stages:

1. **Choose a category**
   - Funny
   - Gang
   - Police
   - Survival
   - Racing
   - Delivery
   - Horror
   - World Event
   - Custom

2. **Choose the core gameplay**
   Examples: chase, defend, deliver, eliminate enemies, rescue NPC, escape, race, protect convoy, investigate, survive waves.

3. **Choose the location**
   Use a GTA V area or a generic environment if the exact location does not matter.

4. **Choose NPCs / enemies / allies**
   Keep counts bounded and appropriate for performance.

5. **Choose vehicles or special world elements**
   Only if relevant to the selected gameplay.

6. **Choose difficulty**
   Easy / Normal / Hard, or a configurable setting.

7. **Choose rewards**
   Balanced cash reward, no-reward mode, unlock/progression inside the mod, or cosmetic feedback. Never turn this into an unlimited-money cheat.

8. **Choose UI and controls**
   Decide whether the mod needs a menu, map marker, help text, notifications, or a simple hotkey.

9. **Review the build brief**
   Show the final selections in a compact summary and catch contradictions.

10. **Build Mod**
   Produce the actual implementation using the main GTA V Legacy Mod Creator standards: compatible dependencies, code, file layout, install/uninstall instructions, testing status, and package files when tools allow.

## Smart branching

Skip irrelevant steps. For example, a street race may not need enemy NPC selection, while a survival mission may not need a reward choice if the user asked for a no-reward challenge.

If a design choice would require an unnecessary dependency, prefer the simpler implementation.

## Safety

Apply the plugin's anti-cheat policy throughout the design. If a selected mechanic becomes a cheat feature, replace it with a fair mission-scoped alternative and explain the adjustment briefly.

## Completion behavior

Once all necessary choices are known, do not keep asking design questions. Move into implementation.
